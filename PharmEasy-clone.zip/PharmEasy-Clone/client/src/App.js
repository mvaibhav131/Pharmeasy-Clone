
import Mainroutes from "./Routes/Mainroutes";


function App() {
  return (
     <div>
      <Mainroutes/>
      </div>
      );
 }
export default App;
